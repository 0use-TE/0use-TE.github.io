import{l as o,a as r}from"../chunks/BW55hdbe.js";export{o as load_css,r as start};
