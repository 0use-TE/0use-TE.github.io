import{l as o,a as r}from"../chunks/CtW-r7f0.js";export{o as load_css,r as start};
