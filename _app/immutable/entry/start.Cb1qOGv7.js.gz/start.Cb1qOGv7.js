import{l as o,a as r}from"../chunks/B_rZgB5A.js";export{o as load_css,r as start};
