import{l as o,a as r}from"../chunks/B4toltzH.js";export{o as load_css,r as start};
