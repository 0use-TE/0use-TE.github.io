import{l as o,a as r}from"../chunks/B19F5bU0.js";export{o as load_css,r as start};
