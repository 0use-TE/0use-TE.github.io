import{l as o,a as r}from"../chunks/DAXp6cOc.js";export{o as load_css,r as start};
