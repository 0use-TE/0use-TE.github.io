import{l as o,a as r}from"../chunks/dOE8cBYY.js";export{o as load_css,r as start};
