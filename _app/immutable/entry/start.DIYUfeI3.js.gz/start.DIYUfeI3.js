import{l as o,a as r}from"../chunks/CUfHz4f6.js";export{o as load_css,r as start};
